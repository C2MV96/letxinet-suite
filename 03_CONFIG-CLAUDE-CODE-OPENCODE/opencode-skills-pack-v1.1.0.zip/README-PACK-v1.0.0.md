# LetXinet opencode skills pack v1.0.0

## Estructura

skills/
- letxinet-megaskill-maestra/SKILL.md  (44.22 KB, 769 lines) - documento director / catalogo
- letxinet-search-best-practices/SKILL.md  (22.11 KB) - pool 2026-08-07 recomendaciones
- letxinet-dual-mcps/  (60 dirs)
  - gateway-markitdown-pdf-extraction/SKILL.md
  - gateway-word-bibliography-reports/SKILL.md
  - osm-word-neighborhood-analysis/SKILL.md
  - ... (57 dirs mas)
  - cross-multi-language-thesaurus-reconstruction/SKILL.md

## Como instalar en opencode

### Windows (PowerShell)
Copiar la carpeta skills/ completa a C:\Users\<USER>\.config\opencode\skills\:

```powershell
$src = "<extract_dir>\skills"
$dst = "C:\Users\<USER>\.config\opencode\skills"
if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst -Force }
Copy-Item -Path "$src\*" -Destination $dst -Recurse -Force
```

### Linux / macOS

```bash
mkdir -p ~/.config/opencode/skills
cp -r skills/* ~/.config/opencode/skills/
```

## Dependencias (NO incluidas en este zip - instalar aparte)

Esta megaskill y los 62 skills individuales son SOLO el layer de documentacion.
Para que sean funcionales necesitas los 4 MCPs activos:

| MCP | Puerto |
|-----|--------|
| letxinet-gateway (V11 Node+TS) | http://127.0.0.1:4003/health |
| letxinet-osm (Go) | http://127.0.0.1:7082/ |
| letxinet-markitdown (Python) | http://127.0.0.1:7860/ |
| omni-word-mcp (Node via COM) | (no HTTP) |

Tras levantar los 4 MCPs, opencode podra invocar automaticamente el skill correcto
segun el request del usuario. La megaskill coordina casos que cruzan 2+ MCPs.