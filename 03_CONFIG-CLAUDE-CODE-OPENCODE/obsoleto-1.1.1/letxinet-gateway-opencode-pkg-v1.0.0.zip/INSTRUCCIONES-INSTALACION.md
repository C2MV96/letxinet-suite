# Instrucciones de Instalacion — Paquete LetXinet Gateway para opencode

**Version del paquete:** 1.0.0 (2026-08-08)
**Target:** opencode (anomalyco/opencode) con soporte MCP
**Req. OS:** Windows 10/11 x64
**Req. RAM:** 8 GB minimo (Suite backend usa ~2.5 GB)
**Req. disco:** 5 GB libres

---

## 1. Contenido del Paquete (5 archivos)

```
letxinet-gateway-opencode-pkg/
├── opencode.json                                   (3.0 KB)  Configuracion principal
├── README-GATEWAY-TOOLS.md                        (~15 KB)  Documentacion de 88+ herramientas
├── PLAN-COMBINACIONES-MCPS.md                     (~25 KB)  10 casos de uso combinando MCPs
├── INSTRUCCIONES-INSTALACION.md                    (este archivo)
└── skills/
    └── letxinet-search-best-practices.md           (~22 KB)  Skill de mejores practicas de busqueda academica
```

**Zip total:** `letxinet-gateway-opencode-pkg-v1.0.0.zip` (~70 KB)

---

## 2. Prerequisitos NECESARIOS (instalar antes)

Antes de copiar el paquete, verifica que tienes:

### 2.1 LetXinet Suite v1.1.0 instalado (RECOMENDADO)

**Si ya instalaste el Suite Suite v1.1.0 (VariantA o VariantB):**

- Backend corriendo en http://127.0.0.1:43123 (LetXinet Desktop HF via main.cjs + server.cjs)
- MCP V11 Gateway corriendo en http://127.0.0.1:4003 (NSSM service `LetXinetMcpV11`)
- OSM-MCP corriendo en http://127.0.0.1:7082 (NSSM service `LetXinetOsmMcp`)
- MarkItDown API corriendo en http://127.0.0.1:7860 (NSSM service `LetXinetMarkdownMCP`)
- Omni Word MCP NO se instala con el Suite — se lanza standalone desde `D:\OTROS\OMNI-Office-Word-MCP-Server\`

**Si NO tienes Suite Suite instalado:** primero instala `LetXinet-Suite-1.1.0-VariantA-Setup.exe` (o VariantB), despues continua aqui.

### 2.2 Node.js (para Omni Word MCP)

Instalar Node.js 18.x o superior desde https://nodejs.org (LTS recomendado)
Verificar:
```powershell
node --version  # debe dar v18.x o superior
npm --version
```

### 2.3 Python 3.x (para MarkItDown API si Suite no esta corriendo)

Solo si no vas a usar el Suite:
- Python 3.10+ desde https://python.org
- Librerias: ver `markitdown-payload/requirements.txt` (PyMuPDF4LLM, FastAPI, etc.)

### 2.4 Repo OMNI-Office-Word-MCP-Server clonado/deployado

Si no tienes `D:\OTROS\OMNI-Office-Word-MCP-Server\`:
```powershell
cd D:\OTROS
git clone <repo-de-omni-word-mcp> OMNI-Office-Word-MCP-Server
cd OMNI-Office-Word-MCP-Server
npm install
npm run build  # genera dist/index.js
```

---

## 3. Passo a Paso — Instalacion del Paquete (5 minutos)

### Paso 1: Descomprimir el paquete zip

```powershell
# Copiar el zip a D:\otra ubicacion
Expand-Archive -Path "letxinet-gateway-opencode-pkg-v1.0.0.zip" -DestinationPath "D:\OTROS\opencode-pkg-letxinet" -Force
```

Resultado:
```
D:\OTROS\opencode-pkg-letxinet\
├── opencode.json
├── README-GATEWAY-TOOLS.md
├── PLAN-COMBINACIONES-MCPS.md
├── INSTRUCCIONES-INSTALACION.md
└── skills\letxinet-search-best-practices.md
```

### Paso 2: Crear/cargar el skill en opencode

opencode carga skills desde `~/.config/opencode/skills/<skill-name>/SKILL.md`. En Windows: `C:\Users\USER\.config\opencode\skills\`.

```powershell
$skillDir = "C:\Users\USER\.config\opencode\skills\letxinet-search-best-practices"
if (-not (Test-Path $skillDir)) {
  New-Item -ItemType Directory -Path $skillDir -Force | Out-Null
}
Copy-Item "D:\OTROS\opencode-pkg-letxinet\skills\letxinet-search-best-practices.md" "$skillDir\SKILL.md" -Force
Write-Output "Skill instalado en $skillDir\SKILL.md"
```

### Paso 3: Copiar el `opencode.json` a tu proyecto

opencode busca `opencode.json` en el directorio de tu proyecto. Tienes 2 opciones:

**Opcion A — Global (todos los proyectos):** copiar a `~/.config/opencode/opencode.json`:
```powershell
Copy-Item "D:\OTROS\opencode-pkg-letxinet\opencode.json" "C:\Users\USER\.config\opencode\opencode.json" -Force
```

**Opcion B — Por proyecto:** copiar al root del proyecto donde quieres usar LetXinet Gateway:
```powershell
Copy-Item "D:\OTROS\opencode-pkg-letxinet\opencode.json" "C:\ruta\mi-proyecto\opencode.json" -Force
```

Recomendado: Opcion B (override por proyecto, no afecta otros opencode configs).

### Paso 4: Verificar paths de los binarios MCP

Abre el `opencode.json` copiado y verifica que las rutas coinciden con tu instalacion:

```json
"mcp": {
  "letxinet-gateway": {
    "command": ["node", "D:\\OTROS\\LETXIPU-SEARCH-MCP-V11-LOCAL\\packaging\\dist\\server.js"],
    ...
  },
  "letxinet-osm": {
    "command": ["D:\\OTROS\\letxipu-osm-mcp\\osmmcp-patched.exe"],
    ...
  },
  "letxinet-markitdown": {
    "http_url": "http://127.0.0.1:7860/sse",
    ...
  },
  "omni-word-mcp": {
    "command": ["node", "D:\\OTROS\\OMNI-Office-Word-MCP-Server\\dist\\index.js"],
    ...
  }
}
```

**Si Suite Suite esta instalado en otra ubicacion (ej. otra PC):** actualiza las rutas en el JSON.

Si Suite Suite v1.1.0 esta instalado en `C:\Program Files\LetXinet Suite\`, los binarios funcionan asi:
- MCP V11: corre como servicio NSSM, no necesitas el command local (se conecta via HTTP al Suite backend)
- OSM-MCP: corre como servicio NSSM tambien — http://127.0.0.1:7082
- MarkItDown API: corre como servicio NSSM en http://127.0.0.1:7860/sse

**Si Suite NO instalado:** necesitas arrancar los binarios standalone (ver seccion 5).

### Paso 5: Configurar API keys

El `opencode.json` usa placeholders `${OPENCODE_API_KEY}` y `${SERPAPI_API_KEY}`. Tienes 2 opciones:

**Opcion A — Variables de entorno del shell:**
```powershell
# En PowerShell, antes de arrancar opencode:
$env:OPENCODE_API_KEY = "tu-key-aqui"  # para LLM (GLM 5.2 via opencode.ai)
$env:SERPAPI_API_KEY  = "tu-serpapi-key-aqui"  # para la fuente `serpapi` (Google Scholar wrapper)
opencode  # arrancar opencode con las env vars cargadas
```

**Opcion B — Editar el `opencode.json`** reemplazando los `${VAR}` por tus keys (no recomendado por seguridad, pero OK para dev/locally).

### Paso 6: Verificar servicios backend

Antes de arrancar opencode, los 4 servicios MCP deben estar corriendo. Verifica:

```powershell
# 1. Suite backend (HTTP 43123)
Invoke-WebRequest -Uri "http://127.0.0.1:43123/api/health" -UseBasicParsing -TimeoutSec 5
# Debe responder 200 OK

# 2. MCP V11 (HTTP 4003)
Invoke-WebRequest -Uri "http://127.0.0.1:4003/health" -UseBasicParsing -TimeoutSec 5
# Debe responder 200 OK

# 3. OSM-MCP (HTTP 7082)
Invoke-WebRequest -Uri "http://127.0.0.1:7082/" -UseBasicParsing -TimeoutSec 5
# Debe responder

# 4. MarkItDown API (HTTP 7860)
Invoke-WebRequest -Uri "http://127.0.0.1:7860/" -UseBasicParsing -TimeoutSec 5
# Debe responder
```

Si alguno falla, arrange:
- Suite no responde: `restart-suite.cmd` o manualmente
- MCP V11 no responde: start NSSM service `LetXinetMcpV11`
- OSM-MCP no responde: start NSSM service `LetXinetOsmMcp`
- MarkItDown no responde: start NSSM service `LetXinetMarkdownMCP`

### Paso 7: Arrancar opencode

```powershell
cd C:\ruta\mi-proyecto  # directorio donde copiaste opencode.json
opencode  # arrancar en modo MCP
```

opencode leera el `opencode.json`, conectara los 4 MCPs, y tendras 88+ herramientas disponibles.

---

## 4. Verificacion Post-Instalacion

Una vez en opencode, prueba estos comandos basicos:

```
> list available tools from letxinet-gateway
> list available tools from letxinet-osm
> letxinet-gateway_health_check
> letxinet-osm_osm_health
> letxinet-markitdown_markitdown_health
> letxinet-gateway_search(query="pobreza Lima", sources=["renati"], maxSources=5, fastMode=true)
```

Si todo responde, ya tienes LetXinet Gateway operando con opencode.

---

## 5. Setup SIN Suite Suite (variantes standalone)

Si solo quieres ciertos MCPs sin Suite Suite v1.1.0 completo:

### 5.1 Solo MCP V11 Gateway (academic search)

Binario precompilado standalone:
```powershell
# Opcion 1: portable single-exe
D:\OTROS\LETXIPU-SEARCH-MCP-V11-LOCAL\packaging\MCP-V11-Local.exe
# Escuchara en http://127.0.0.1:4003

# Opcion 2: portable zip descomprimido y arrancar server.js
Expand-Archive "D:\OTROS\LETXIPU-SEARCH-MCP-V11-LOCAL\packaging\MCP-V11-Local-Portable.zip" -DestinationPath "D:\mcp-v11-portable"
cd D:\mcp-v11-portable
npm start  # arranca server.js en puerto 4003
```

En `opencode.json`, modifica:
```json
"letxinet-gateway": {
  "command": ["node", "D:\\mcp-v11-portable\\dist\\server.js"],
  ...
}
```

### 5.2 Solo OSM-MCP (geoespacial)

Binario standalone:
```powershell
D:\OTROS\letxipu-osm-mcp\osmmcp-patched.exe
# Escuchara en http://127.0.0.1:7082
```

No requiere configuracion extra en `opencode.json` — solo el command.

### 5.3 Solo MarkItDown (PDF a Markdown)

```powershell
cd D:\OTROS\LETXINET-SUITE\src-suite\componentes-parches\markitdown-api\markitdown-payload
pip install -r requirements.txt
python app.py  # arranca FastAPI en http://127.0.0.1:7860
```

El `opencode.json` ya usa `http_url` HTTP, no command — asi que funcionara solo.

### 5.4 Solo Omni Word (Word docs sin search)

```powershell
cd D:\OTROS\OMNI-Office-Word-MCP-Server
npm install
npm run build
npm start  # si tiene start script, o: node dist/index.js
```

---

## 6. Troubleshooting Comun

### 6.1 "MCP Not Connected" en opencode

- Verifica que los servicios backend esten corriendo (ver Paso 6)
- Verifica que los paths en `opencode.json` apuntan a binarios existentes
- Verifica timeout en `opencode.json` — si es muy breve (60s), aumentalo a 3600000 para el gateway

### 6.2 "socket hang up" en busquedas lentas

- NO uses group sources (`latam`, `all`, `tesis`)
- Usa sources individuales (`renati`, `scielo`, `pubmed`, etc.)
- Carga el skill antes de invocar
- Limit `maxSources=5` para evitar cascading timeouts

### 6.3 "Invalid sort parameter: trending" en `huggingface`

- Bug conocido en el endpoint HF. No fixeable localmente.
- Workaround: filtrar por topic en `trending_papers(query="language model")`

### 6.4 Bridge subprocess muere tras 10 min en busquedas largas

- Verifica que estas usando `letxinet-gateway_search` con sources individuales (no groups)
- Aumenta timeout en opencode.json a `3600000` (60 min)
- Si aun asi colapsa: usa el fallback REST desde PowerShell (ver README-GATEWAY-TOOLS.md seccion 7.5)

### 6.5 "Cannot read properties of null (reading 'message')" en pdf_metadata

- Bug conocido en URLs `hdl.handle.net` (institutional repositories)
- Workaround: usa URL directa al PDF o DOI, no handle URLs

### 6.6 OSM-MCP "degraded" status

- OSRM backend puede estar down sin afectar Nominatim y Overpass
- Las heramientas que dependen de routing (route_fetch, get_route_directions, analyze_commute) fallaran
- POIs y geocoding siguen funcionando via Nominatim/Overpass OK

---

## 7. Estructura Final Recomendada

```
C:\Users\USER\
├── .config\
│   └── opencode\
│       ├── opencode.json              # global (o copiar a proyecto)
│       └── skills\
│           └── letxinet-search-best-practices\
│               └── SKILL.md           # skill de mejores practicas
└── mi-proyecto\
    ├── opencode.json                  # override por proyecto (recommended)
    └── ... mi codigo

D:\OTROS\
├── LETXIPU-SEARCH-MCP-V11-LOCAL\       # source TS del Gateway
│   └── packaging\dist\server.js       # binario servidor MCP V11
├── letxipu-osm-mcp\
│   └── osmmcp-patched.exe             # binario OSM MCP (Go)
├── LETXINET-SUITE\
│   └── src-suite\componentes-parches\
│       └── markitdown-api\
│           └── markitdown-payload\
│               ├── app.py             # servidor MarkItDown (Python FastAPI)
│               ├── mcp-adapter\
│               └── python-runtime\     # runtime Python embebido
├── OMNI-Office-Word-MCP-Server\
│   └── dist\index.js                  # binario Word MCP (Node.js)
└── opencode-pkg-letxinet\             # contenido del paquete descomprimido
    ├── opencode.json
    ├── README-GATEWAY-TOOLS.md
    ├── PLAN-COMBINACIONES-MCPS.md
   └── INSTRUCCIONES-INSTALACION.md
```

---

## 8. Soporte

- Issues del paquete: reportar con log del comando failing y version del Suite instalada
- Issues del MCP V11: `D:\OTROS\PRUEBAS-LETXINET\fuentes-individuales\Informe-Fuentes-Individuales-2026-08-07.md`
- Skill de mejores practicas puede actualizarse: editar `C:\Users\USER\.config\opencode\skills\letxinet-search-best-practices\SKILL.md`

---

**Fin de las instrucciones.**

Paquete generado el 2026-08-08 por opencode para Suite Suite v1.1.0.
