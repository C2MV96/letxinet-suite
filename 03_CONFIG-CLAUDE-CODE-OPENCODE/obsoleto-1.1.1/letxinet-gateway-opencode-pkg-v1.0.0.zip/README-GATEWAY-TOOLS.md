# LetXinet Gateway — README Completo de Herramientas (4 MCPs)

**Version:** LetXinet Gateway V11.0.0
**Fecha:** 2026-08-08
**Pool de fuentes:** 39 fuentes academicas (30 operativas, 8 empty, 1 DEAD)
**MCPs configurados:** 4 (letxinet-gateway, letxinet-osm, letxinet-markitdown, omni-word-mcp)
**Total de herramientas:** 88+ herramientas MCP combinadas

---

## 1. Resumen Ejecutivo

LetXinet Gateway es el ecosistema de 4 MCP servers que dan capacidades de:

1. **Busqueda academica** (28 Herramientas) — `letxinet-gateway` V11
2. **Geoespacial** (41 Herramientas) — `letxinet-osm` (Go binary)
3. **Documentos PDF/Office** (2 Herramientas) — `letxinet-markitdown` (Python)
4. **Documentos Word** (18 Herramientas) — `omni-word-mcp` (Node.js)

Cuando se configuran los 4 juntos en opencode, el async coding agent tiene capacidades de investigacion academica mundial + analisis geoespacial + procesamiento de documentos PDF/Word — todo en una misma sesion.

---

## 2. MCP 1: `letxinet-gateway` (28 herramientas)

**Binario:** Node.js + TypeScript compilado
**Ubicacion binario:** `D:\OTROS\LETXIPU-SEARCH-MCP-V11-LOCAL\packaging\dist\server.js`
**Puerto cuando se invoca via Suite:** http://127.0.0.1:4003
**Skill requerido:** `letxinet-search-best-practices` (cargar antes de usar)

### 2.1 Herramientas de Busqueda Academica (5)

| Herramienta | Descripcion | Params clave | Notas |
|-------------|-------------|--------------|-------|
| `search` | Busqueda academica de una sola consulta | `query`, `sources=["renati"]`, `maxSources=5`, `fastMode=true` | 4x mas rapida que `smart_search` — USAR POR DEFECTO |
| `batch_search` | Multiples queries en paralelo + deduplicacion | `queries=["q1","q2",...]`, `maxResults=60`, `sources` | 2x mas resultados, ideal para broad recall |
| `smart_search` | Search con expansion sinonimos ES/EN/PT + broader/narrower | `query`, `maxResults=30`, `sources` | Mas lento, similar calidad. Evitar a menos que el user pida "expanded" |
| `list_sources` | Lista las 39 fuentes disponibles con metadata | ninguno | Retorna fuentes, grupos (latam, global, tesis, ai_ml, etc), total |
| `health_check` | Verifica conectividad a todas las fuentes y API keys | ninguno | Retorna status, latency, keys configuradas |

### 2.2 Metadata de Papers (3)

| Herramienta | Descripcion | Recomendado |
|-------------|-------------|-------------|
| `enrich_metadata` | Enriquece metadata (abstract, DOI, year, university, authors, PDF URL) via OpenAlex + Crossref + Semantic Scholar + DSpace7 + HTML scraping | USAR ESTE |
| `fetch_metadata` | Metadata de 1 papel por DOI/URL/title. Retorna completenessScore, enrichedFields, repoHandleUrl, pdfUrl | DEPRECATED — solo 1 fuente |
| `recover_metadata` | Recovery profundo (5 fuentes encadenadas: OpenAlex->Crossref->Semantic Scholar->DSpace7->HTML->ALICIA) | DEPRECATED — timeout 240s en DOIs. No usar |

### 2.3 Resolucion y Descarga PDF (2)

| Herramienta | Descripcion |
|-------------|-------------|
| `resolve_pdf` | Resuelve URL final del PDF sin descargarlo. Retorna URL, fuente de resolucion, pasos. Mas rapido que `download_pdf` |
| `download_pdf` | Resuelve URL de descarga via 9 fallback sources: Sci-Hub, Unpaywall, CORE, Semantic Scholar, PMC, OA.mg, WeLib, Google Scholar. Retorna URL lista |

### 2.4 Lectura y Analisis de PDFs (8)

| Herramienta | Descripcion | Cuando usar |
|-------------|-------------|-------------|
| `read_pdf` | Extrae texto de PDF como Markdown estructurado (via MinerU AI con OCR, table & formula recognition) o raw text | Cuando necesitas texto rapido |
| `read_pdf_markdown` | PDF a Markdown estructurado preservando headings, tablas, listas. Usa MinerU AI OCR + layout analysis. **Mucho mas token-efficient que read_pdf para LLM** | PREFERIDO para LLM consumption |
| `pdf_smart_summary` | Resumen token-efficient de PDF academico. Overview estructurado (abstract, methods, results, conclusions) truncado al budget de tokens. **Best first tool antes de diving deep** | PRIMER PASO al analizar un PDF nuevo |
| `pdf_metadata` | Metadata del PDF: titulo, autor, page count, fecha creacion, tamanho archivo | Rapido <2s en URLs publicas. FALLA en hdl.handle.net URLs |
| `pdf_sections` | Detecta secciones del paper (Abstract, Methods, Results, etc.). DEPRECATED — lento en PDFs >30pags | Preferir pdf_smart_summary + read_pdf_markdown con pages= |
| `pdf_citations` | Extrae citas y lista de referencias del PDF. Parsea numbered [1] y author-year | Util para bibliografia |
| `extract_section` | Extrae una seccion especifica del PDF por nombre ("metodologia", "marco teorico", "results"). Full text sin limite. Fuzzy matching ES/EN | Cuando necesitas EL texto completo de una seccion |
| `analyze_academic` | Deep analysis de documentos academicos (tesis, articulos). Detecta tipo doc, idioma, 22 tipos de seccion, datos estadisticos (p-values, correlations, ANOVA, chi2, regressions, sample sizes) | TOP para revision sistematica |

### 2.5 Conversion de Documentos (3)

| Herramienta | Descripcion |
|-------------|-------------|
| `convert_document` | Convierte cualquier documento (PDF, DOCX, PPTX, XLSX, imagenes) a Markdown estructurado via MinerU AI. OCR para 109 idiomas, table recognition, formula-to-LaTeX |
| `batch_convert` | Convierte multiples documentos a Markdown en paralelo. Max 10 por batch. Retorna summary por doc |
| `extract_tables` | Extrae todas las tablas de un doc como HTML o Markdown via MinerU ML. Maneja rotated, cross-page, merged-cell tables |
| `extract_formulas` | Extrae formulas matematicas como LaTeX via MinerU UniMERNet. Maneja nested, multi-line, display math |

### 2.6 Fuentes Premium y CS/AI (4)

| Herramienta | Descripcion | API key |
|-------------|-------------|---------|
| `search_dblp` | Search DBLP Computer Science Bibliography. Publications, authors, venues. BibTeX-ready | Ninguna |
| `search_paperswithcode` | Papers With Code — papers con source code, benchmarks, datasets, methods | Ninguna |
| `trending_papers` | HuggingFace Daily Papers — AI/ML trending. Filtro opcional por topic | Ninguna |
| `search_conferences` | OpenReview — conference papers (ICLR, NeurIPS, ICML) | Ninguna |

### 2.7 Utilidades (3)

| Herramienta | Descripcion |
|-------------|-------------|
| `coverage_report` | Metricas de cobertura por pais/fuente — active/down repos, % abstract, response time. Util para detectar gaps en LatAm |
| `help` | Ayuda y examples para cualquier tool o fuente. Pasar "all" para doc completa |
| `verify_antihallucination_data` | Agente verificacion anti-alucinacion. Analiza datos numericos, %, estadisticas, autores, years contrastando contra textos extraidos |

### 2.8 Las 39 Fuentes Disponibles

**OPERATIVAS (30) - llamar individualmente:**

| Continente | Fuentes | Tipo |
|-----------|---------|------|
| Global | `semantic` (48 res), `openalex` (49), `pubmed` (5), `arxiv` (8), `scopus` (8), `crossref` (5), `doaj` (1), `zenodo` (8), `openaire` (7), `core` (3), `serpapi` (8 - Google Scholar wrapper, HIDDEN TREASURE) | free + premium |
| LatAm | `scielo` (8), `lareferencia` (49), `laref_ecuador` (30), `renati` (1), `bdtd` (49), `unam` (1), `anid` (13), `snrd` (12), `espana` (30), `costarica` (30), `uruguay` (30), `elsalvador` (30), `laref_peru` (30), `laref_brasil` (30), `laref_mexico` (30), `laref_argentina` (30), `laref_colombia` (30), `laref_chile` (30), `oasisbr` (22, RE-ESTABILIZED), `rraae` (49, RE-ESTABILIZED - top biotech relevance) | free |
| CS/AI | `dblp`, `paperswithcode`, `openreview`, `huggingface` — solo para CS/AI queries | free |

**EMPTY (8) — funcionales pero sin match en biotech:** `redalyc`, `minciencias`, `conacyt`, `huggingface`

**DEAD (1) - NO LLAMAR:** `alicia` (Peru CONCYTEC, 90s timeout)

---

## 3. MCP 2: `letxinet-osm` (41 herramientas)

**Binario:** `D:\OTROS\letxipu-osm-mcp\osmmcp-patched.exe` (23.55 MB, Go)
**Puerto:** http://127.0.0.1:7082
**Backends:** Nominatim (geocoding), Overpass (OSM data), OSRM (routing)
**Estado actual:** `degraded` (OSRM down — pinga en 357ms pero responde down, Nominatim OK 265ms, Overpass OK 331ms)

### 3.1 Geocoding (4)

| Herramienta | Descripcion |
|-------------|-------------|
| `geocode_address` | Convierte address/place/MGRS/UTM/DMS a lat/lon. Auto-detecta MGRS military (e.g. "54SVK2747201448"), UTM, DMS. Essential para tactical coords |
| `reverse_geocode` | Convierte lat/lon a direccion humana legible. Soporta lang ES/EN/PT/FR/DE |
| `get_version` | Version del OSM MCP service |
| `osm_health` | Status de los 3 backends (Nominatim, OSRM, Overpass). Status: healthy/degraded/unhealthy |

### 3.2 Routing (6)

| Herramienta | Descripcion |
|-------------|-------------|
| `get_route_directions` | Direcciones entre 2 puntos (start_lat/start_lon -> end_lat/end_lon). Modos: car, bike, foot |
| `route_fetch` | Fetch route entre 2 puntos via OSRM. Retorna polyline encoded, distance, duration |
| `route_sample` | Muestrea puntos a lo largo de una route a intervalos (metros) |
| `polyline_encode` | Encode de lat/lon array a polyline string |
| `polyline_decode` | Decode de polyline string a lat/lon array |
| `enrich_emissions` | Enriquece route options con CO2 emissions, calorie burn, cost estimates |

### 3.3 POIs y Places (5)

| Herramienta | Descripcion |
|-------------|-------------|
| `find_nearby_places` | POIs cerca de lat/lon con radio (max 50km) y category filter (restaurant, hotel, park, etc.) |
| `find_nearby_batch` | Bulk find_nearby_places — hasta 10 sub-queries en paralelo. Cada una {lat, lon, radius, category, limit, label} |
| `find_charging_stations` | EV charging stations cerca de lat/lon (radio max 10km) |
| `find_parking_facilities` | Parking facilities cerca de lat/lon (radio max 5km). Filtro por tipo: surface, underground, multi-storey |
| `find_schools_nearby` | Educ institutions cerca de lat/lon (radio max 5km). Filtro school_type: elementary, secondary, university, college |

### 3.4 Geografia y Areas (4)

| Herramienta | Descripcion |
|-------------|-------------|
| `explore_area` | Describe un area basada en coords + radio (max 5km) |
| `analyze_neighborhood` | Evalua livability de un neighborhood. Include price data opcional. Busca amenities, transport, etc. |
| `analyze_commute` | Analiza opciones de transporte entre home y work locations. Modos: car, cycling, walking |
| `suggest_meeting_point` | Sugiere meeting points optimos para multiples participantes. Category: restaurant, cafe, etc. |

### 3.5 Mapas y OSM Raw (5)

| Herramienta | Descripcion |
|-------------|-------------|
| `get_map_image` | Retrieve OSM map image para analisis (zoom 1-19) |
| `tile_cache` | Manage cached map tiles. Actions: list, get, stats. Tile coords x/y/zoom |
| `osm_query_bbox` | Query raw OSM data dentro de bounding box con tag filters (amenity, shop, leisure, highway, building, name, cuisine, brand) |
| `filter_tags` | Filtra OSM elements por tags (key-value pairs) |
| `sort_by_distance` | Sort OSM elements por distancia de un ref point |

### 3.6 Geo Utils (4)

| Herramienta | Descripcion |
|-------------|-------------|
| `geo_distance` | Distancia Haversine entre 2 coords |
| `centroid_points` | Centroide geografico (mean center) de un set de coords |
| `bbox_from_points` | Bounding box que cubre todos los puntos dados |
| `polygon_from_admin` | Polygon admin boundary (GeoJSON Polygon/MultiPolygon) via Overpass. Param name (REQUIRED) + admin_level 1-11 (2=country, 4=state, 8=province, 10=neighbourhood) |

**TOTAL OSM: 41 herramientas** (4 + 6 + 5 + 4 + 5 + 4 + 13 misc identificadas)

---

## 4. MCP 3: `letxinet-markitdown` (2 herramientas)

**Servicio:** Python FastAPI en http://127.0.0.1:7860/sse (`markitdown-payload/app.py`)
**Runtime embedido:** Python 3.x portable en `componentes-parches/markitdown-api/markitdown-payload/python-runtime/` (223 MB)
**Librerias:** PyMuPDF4LLM (motor principal), MinerU AI (OCR + layout)
**Endpoint SSE para MCP:** http://127.0.0.1:7860/sse

### 4.1 Herramientas (2)

| Herramienta | Descripcion |
|-------------|-------------|
| `markitdown-api_markitdown_convert` | Convierte PDF local a Markdown estructurado via API local (PyMuPDF4LLM). Params: path (absoluta PDF), pages (all/1-5/first5/last3/1,3,5/7), maxChars. Retorna {success, markdown, chars, lines, total_pages} |
| `markitdown-api_markitdown_health` | Status del servicio MarkItDown API local |

### 4.2 Nota MCP MarkItDown vs `letxinet-gateway` PDF tools

El Gateway V11 tambien expone `read_pdf`, `read_pdf_markdown`, `convert_document` (todas via MinerU AI), pero `markitdown-api` ofrece una ruta ALTERNATIVA local sin pasar por el Suite. 

**Cuando usar cual?**
- **`markitdown-api_markitdown_convert`** — PDFs LOCALES con path absoluto (rapido, no network)
- **`letxinet-gateway.read_pdf_markdown`** — PDFs URL/DOI o path local con OCR avanzado + layout completo via MinerU

El V11 Gateway usa MinerU AI (mejor calidad, OCR en 109 idiomas), pero requiere red. MarkItDown API usa PyMuPDF4LLM (rapido local, sin red, sufficient para PDFs_sin_imagenes standard).

---

## 5. MCP 4: `omni-word-mcp` (18 herramientas)

**Binario:** Node.js en `D:\OTROS\OMNI-Office-Word-MCP-Server\dist\index.js`
**Libreria:** `docx` (npm)
**Proposito:** Crear/editar Word documents programaticamente desde opencode

### 5.1 Creacion y Estructura (5)

| Herramienta | Descripcion |
|-------------|-------------|
| `create_document` | Crea nuevo .docx con metadata opcional (title, author) |
| `copy_document` | Copia un doc existente |
| `add_heading` | Agrega heading (level 1-9, donde 1 es el mas alto) |
| `add_paragraph` | Agrega parrafo con style opcional |
| `add_page_break` | Agrega page break |

### 5.2 Edicion (5)

| Herramienta | Descripcion |
|-------------|-------------|
| `add_table` | Agrega tabla (rows x cols) con data opcional 2D |
| `add_picture` | Agrega imagen (image_path, width opcional inches) |
| `add_endnote_to_document` | Agrega endnote a un paragraph_index (0-based) |
| `add_footnote_to_document` | Agrega footnote a un paragraph_index |
| `delete_paragraph` | Elimina paragraph por index (0-based) |

### 5.3 Formato y Estilos (5)

| Herramienta | Descripcion |
|-------------|-------------|
| `format_text` | Formato range texto en un paragraph. bold/italic/underline, color, font_size, font_name |
| `create_custom_style` | Crea custom style. bold/italic, font_size, font_name, color, base_style |
| `format_table` | Format table con borders, shading, has_header_row, border_style |
| `customize_footnote_style` | Customize footnote numbering y formatting |
| `search_and_replace` | Search/replace all occurrences de un text |

### 5.4 Seguridad (2)

| Herramienta | Descripcion |
|-------------|-------------|
| `protect_document` | Agrega password protection al doc |
| `unprotect_document` | Remueve password protection |

### 5.5 Lectura y Busqueda (3)

| Herramienta | Descripcion |
|-------------|-------------|
| `get_document_info` | Info del documento (metadata) |
| `get_document_text` | Extrae todo el texto del doc |
| `get_document_outline` | Estructura del doc |
| `get_paragraph_text_from_document` | Texto de 1 paragraph por index (0-based) |
| `find_text_in_document` | Find occurrences de un text. match_case, whole_word |
| `list_available_documents` | Lista todos los .docx en el directorio |

**TOTAL OMI-WORD: 18 herramientas**

---

## 6. Compatible opencode MCP servers — Resumen

En el `opencode.json` se configuran los 4 MCPs en paralelo:

```
"mcp": {
  "letxinet-gateway":  { tipo: local, command: ["node", "...\\server.js"], timeout: 60min },  // 28 tools academica
  "letxinet-osm":     { tipo: local, command: ["...\\osmmcp-patched.exe"], timeout: 60s },   // 41 tools geoespacial
  "letxinet-markitdown": { tipo: local, http_url: "...:7860/sse", timeout: 30min },          // 2 tools PDF local
  "omni-word-mcp":    { tipo: local, command: ["node", "...\\dist\\index.js"], timeout: 60s } // 18 tools Word
}

TOTAL HERRAMIENTAS: 28 + 41 + 2 + 18 = 89 herramientas MCP
```

---

## 7. Flujo de Trabajo Recomendado

### 7.1 Investigacion academica clasica

```
1. skill letxinet-search-best-practices   <- Cargar skill primero
2. search (sources=["openalex","pubmed","renati"], fastMode=true, maxSources=5)
3. Para cada paper interesante:
   a. resolve_pdf (URL -> resolvedor fallback)
   b. download_pdf (si necesario descargar)
   c. pdf_smart_summary (overview rapido)
   d. extract_section ("metodologia" si necesitas detalle)
   e. (opcional) verify_antihallucination_data (anti-alucinacion)
4. (opcional) omni-word-mcp:
   a. create_document("Resumen-Bibliografico.docx")
   b. add_heading("Introduccion", 1)
   c. add_paragraph("Segun autores...") por cada paper
```

### 7.2 Investigacion geoespacial (punto de interes)

```
1. skill letxinet-search-best-practices
2. letxinet-osm.geocode_address("Av. Javier Prado 1234, Lima")  -> lat/lon
3. letxinet-osm.analyze_neighborhood(lat, lon, radius=1000, include_price_data=true)
4. letxinet-osm.find_nearby_places(lat, lon, category="hospital", limit=10)
5. letxinet-gateway.search(query="hospitales Lima servicios", sources=["scielo","laref_peru"], fastMode=true)
6. omni-word-mcp:
   a. create_document("Analisis-Vecindario-Javier-Prado.docx")
   b. add_heading("Ubicacion", 1)
   c. add_paragraph("Lat/lon: ...")
   d. add_heading("Servicios cercanos", 1)
   e. add_table(rows=11, cols=3, data=[[...]])
   f. add_heading("Bibliografia", 1)
   g. add_paragraph(resultados)
```

### 7.3 Conversion de tesis fisica a Word editable

```
1. markitdown-api.markitdown_health  (verificar servicio up)
2. markitdown-api.markitdown_convert(path="D:\\tesis.pdf", pages="all")
3. omni-word-mcp.create_document("Tesis-Convertida.docx")
4. Para cada seccion del Markdown extraido:
   a. add_heading(seccion.titulo, nivel_segun_#)
   b. add_paragraph(seccion.contenido)
```

### 7.4 Analisis estadistico anti-alucinacion

```
1. letxinet-gateway.extract_section(pdf_url, "results")
2. letxinet-gateway.analyze_academic(pdf_url)  -> p-values, ANOVA, chi2, etc.
3. letxinet-gateway.verify_antihallucination_data(
     text_to_verify="LOS resultados mostraron p<0.05 con n=120...",
     extracted_source_texts=[extract_section_result]
   )
4. omni-word-mcp.create_document("Reporte-Verificado.docx")
5. add_paragraph(text_verificado_post_check)
```

---

## 8. Estado actual del Pool — Pool 2026-08-07

| Status | Count | Sources |
|--------|-------|---------|
| OPERATIVAS | 30 | semantic, openalex, pubmed, arxiv, scopus, crossref, doaj, zenodo, openaire, core, scielo, lareferencia, laref_ecuador, renati, bdtd, unam, anid, snrd, espana, costarica, uruguay, elsalvador, laref_peru, laref_brasil, laref_mexico, laref_argentina, laref_colombia, laref_chile, oasisbr (RE-STABILIZED), rraae (RE-STABILIZED - top biotech), serpapi (HIDDEN TREASURE - Google Scholar wrapper) |
| EMPTY | 8 | redalyc, minciencias, conacyt, dblp, paperswithcode, openreview, huggingface (Invalid sort bug), dblp |
| DEAD | 1 | alicia (Peru CONCYTEC HTTP 90s timeout) |
| TOTAL | 39 fuentes | |

Hallazgos 2026-08-07:
- 9 fuentes REVIVIDAS de DEAD a OPERATIVAS
- 2 fuentes RE-ESTABILIZED (oasisbr, rraae)
- 6 nodos `laref_*` subsystem revived via OpenAlex
- `serpapi` = HIDDEN TREASURE (Google Scholar wrapper — papers NOT en OpenAlex/PubMed/SciELO)
- Backup/Native OSRM appears down (357ms timeout) — usar route_fetch con cuidado

Backup del informe completo del pool:
`D:\OTROS\PRUEBAS-LETXINET\fuentes-individuales\Informe-Fuentes-Individuales-2026-08-07.md`

---

**Fin del README.**
