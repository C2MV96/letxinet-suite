# Plan de Combinaciones de MCPs — LetXinet Gateway + OSM + MarkItDown + Word

**Fecha:** 2026-08-08
**MCPs involucrados:** 4 (88+ herramientas en total)
**Objetivo:** Casos de uso reales donde la combinacion de 2 o mas MCPs entrega valor que individualmente no podria

---

## 1. Caso 1: Estudio Bibliografico de Tesis (MCP-Gateway + MCP-Word)

**Contexto:** Alumno de pregrado/postgrado necesita un estado del arte de un tema para tesis

### Flujo (7 pasos)

```
1. skill letxinet-search-best-practices    <- PRERREQUISITO
2. letxinet-gateway_search(
     query="celulosa bacteriana mango Komagataeibacter",
     sources=["openalex","pubmed","scielo","renati","serpapi"],
     maxSources=5, fastMode=true
   )
3. Para cada paper interesante en resultados:
   - letxinet-gateway_resolve_pdf(doi="10.1590/...")
   - letxinet-gateway_pdf_smart_summary(source=url_resuelta, maxTotalChars=4000)
   - OPCIONAL: letxinet-gateway_extract_section(source=url_resuelta, section="metodologia")
4. letxinet-gateway_verify_antihallucination_data(
     text_to_verify="Segun Garcia-Sanchez et al. (2019), la produccion de BC...",
     extracted_source_texts=[seccion_extraida]
   )
5. omni-word-mcp_create_document(
     filename="Estado-del-Arte-BC-Mango.docx",
     title="Estado del Arte: Celulosa Bacteriana con Mango",
     author="LetXinet Gateway"
   )
6. omni-word-mcp_add_heading("1. Introduccion", 1)
   omni-word-mcp_add_paragraph("La celulosa bacteriana...")
   omni-word-mcp_add_heading("2. Produccion via Komagataeibacter", 2)
   ... (una subseccion por cluster tematico)
7. omni-word-mcp_add_heading("Referencias", 1)
   Para cada paper:
     omni-word-mcp_add_paragraph("- Autor et al. (year). Title. Journal. DOI: ...")
```

**Tiempo estimado:** 5-10 minutos automatizado
**Herramientas combinadas:** 6 tools del Gateway + 3 de Word = 9_tools

---

## 2. Caso 2: Site Selection Comercial (MCP-OSM + MCP-Gateway + MCP-Word)

**Contexto:** Cadena de farmacias quiere abrir nueva sucursal — necesita evaluar 3 ubicaciones candidatas

### Flujo (14 pasos)

```
1. letxinet-osm_geocode_address(address="Av. Javier Prado 1234, San Isidro, Lima")
   -> lat=-12.0913, lon=-77.0382
2. Repetir para 2 ubicaciones candidatas mas
3. Para cada ubicacion:
   - letxinet-osm_analyze_neighborhood(lat, lon, radius=1000, include_price_data=true)
   - letxinet-osm_find_nearby_places(lat, lon, category="pharmacy", radius=2000, limit=20)
   - letxinet-osm_find_nearby_places(lat, lon, category="hospital", radius=1500, limit=10)
   - letxinet-osm_find_nearby_places(lat, lon, category="shopping_mall", radius=2000)
   - letxinet-osm_find_parking_facilities(lat, lon, radius=500, limit=5)
   - letxinet-osm_get_route_directions(start, end, mode="car")  -> proximidad a puntos estrategicos
4. letxinet-gateway_search(
     query="acceso a farmacias Lima San Isidro accesibilidad",
     sources=["laref_peru","scielo"],
     fastMode=true, maxSources=5
   )
   -> identificar papers sobre pharmacy access en Lima
5. omni-word-mcp_create_document(
     filename="Site-Selection-Farmacia-2026-08-08.docx",
     title="Site Selection Report - Cadena Farmacia",
     author="LetXinet Gateway Analysis"
   )
6. omni-word-mcp_add_heading("Resumen Ejecutivo", 1)
   omni-word-mcp_add_paragraph("Analisis de 3 candidatos para nueva sucursal...")
7. omni-word-mcp_add_heading("Metodologia", 1)
   omni-word-mcp_add_paragraph("Evaluacion geoespacial multi-factor:POIs farmacias/hospitales, transit car, parking...")
8. omni-word-mcp_add_heading("Candidato 1: Av. Javier Prado 1234", 1)
   omni-word-mcp_add_heading("Ubicacion", 2)
   omni-word-mcp_add_paragraph("Lat: -12.0913, Lon: -77.0382")
   omni-word-mcp_add_heading("Farmacias cercanas (radio 2km)", 2)
   omni-word-mcp_add_table(
     rows=11, cols=4,
     data=[
       ["Nombre","Distancia","Direccion","Tipo"],
       ["Boticas SALUD",...],
       ...
     ]
   )
   omni-word-mcp_add_heading("Hospitales cercanos (radio 1.5km)", 2)
   omni-word-mcp_add_table(...)
9. Repetir paso 8 para Candidato 2 y Candidato 3
10. omni-word-mcp_add_heading("Comparativa", 1)
    omni-word-mcp_add_table(rows=4, cols=5, data=[...comparativa metricas...])
11. omni-word-mcp_add_heading("Bibliografia", 1)
    omni-word-mcp_add_paragraph("Papers de acceso a farmacias - Scielo/Laref Peru")
12. omni-word-mcp_add_heading("Conclusiones y Recomendaciones", 1)
    omni-word-mcp_add_paragraph("Candidato X recomendado. Razon...")
```

**Tiempo estimado:** 15-20 minutos (paralelizable)
**Herramientas combinadas:** 7 OSM + 1 Gateway + 3 Word = 11 tools

---

## 3. Caso 3: Conversion y Edicion de Tesis Scaneada (MCP-MarkItDown + MCP-Word)

**Contexto:** Tesis fisica escaneada en PDF (no selectable text). Necesita convertirse a Word editable

### Flujo (5 pasos)

```
1. markitdown-api_markitdown_health()
   -> verificar servicio up (debe retornar "ok")
2. markitdown-api_markitdown_convert(
     path="D:\\Tesis-Escaneada.pdf",
     pages="all",
     maxChars=200000  # budget amplio
   )
   -> retorna markdown estructurado preservando headings/tablas
3. Parsear markdown en componentes (headings, paragraphs, tablas, listas)
4. omni-word-mcp_create_document(
     filename="Tesis-Convertida-Y-Editable.docx",
     title="Tesis Recuperada de PDF Escaneado",
     author="Original autora: [autora detectada via OCR]"
   )
5. Para cada componente:
   - heading -> omni-word-mcp_add_heading(text, level)
   - paragraph -> omni-word-mcp_add_paragraph(text)
   - table -> omni-word-mcp_add_table(rows, cols, data)
   - picture -> omni-word-mcp_add_picture(image_path, width=5)
```

**Tiempo estimado:** 5-10 minutos por tesis de 150 paginas
**Herramientas combinadas:** 2 MarkItDown + 5 Word = 7 tools
**Nota:** Si el PDF tiene headers/columnas complejas, mejor `letxinet-gateway.read_pdf_markdown` (MinerU AI)

---

## 4. Caso 4: Planificacion de Ruta de Evacuacion + Comunicacion (MCP-OSM + MCP-Word)

**Contexto:** Municipalidad necesita plan de evacuacion de un barrio ante sismo

### Flujo (10 pasos)

```
1. letxinet-osm_polygon_from_admin(name="Miraflores", admin_level=8)
   -> poligono GeoJSON del distrito
2. letxinet-osm_geocode_address(address="Parque Central Miraflores, Lima")
   -> centroid del distrito
3. letxinet-osm_find_nearby_batch(queries=[
     {lat, lon, radius=2000, category="school", limit=20, label="escuelas"},
     {lat, lon, radius=2000, category="hospital", limit=10, label="hospitales"},
     {lat, lon, radius=1000, category="police", limit=10, label="comisarias"},
     {lat, lon, radius=2000, category="fire_station", limit=10, label="bomberos"},
     {lat, lon, radius=2000, category="parking", limit=20, label="estacionamientos-evacuacion"},
     {lat, lon, radius=2000, category="stadium", limit=10, label="estadios-zonas-concentracion"}
   ])
   -> respuestas consolidadas en paralelo
4. Para cada hospital/escuela/centro-evacuacion:
   letxinet-osm_get_route_directions(start_lat, start_lon, end_lat, end_lon, mode="foot")
5. letxinet-osm_analyze_neighborhood(lat=centro.distrito, lon=centro.distrito, radius=2000, include_price_data=false)
   -> densidad, accesibilidad
6. omni-word-mcp_create_document("Plan-Evacuacion-Miraflores.docx")
7. omni-word-mcp_add_heading("Plan Municipal de Evacuacion - Miraflores", 1)
   omni-word-mcp_add_paragraph("Distrito: Miraflores, Lima, Peru")
   omni-word-mcp_add_paragraph("Poligono admin recuperado via OSM Overpass")
8. omni-word-mcp_add_heading("Zonas de Concentracion Seguras", 1)
   omni-word-mcp_add_table(rows=hospitales_total+1, cols=4, data=[...])
9. omni-word-mcp_add_heading("Rutas de Evacuacion", 1)
   omni-word-mcp_add_paragraph("Rutas recomendadas a pie desde cada cuadra a zona de concentracion...")
10. omni-word-mcp_add_heading("Mapa de Accesibilidad Vial", 1)
    omni-word-mcp_add_picture("mapa_rutas.png", width=6)
```

**Tiempo estimado:** 20-30 minutos (varias rutas)
**Herramientas combinadas:** 7 OSM + 4 Word = 11 tools

---

## 5. Caso 5: Revision Sistematica con Anti-Alucinacion (MCP-Gateway + MCP-Word)

**Contexto:** Investigador hace revision sistematica — necesita verificar que los datos citados son correctos

### Flujo (12 pasos)

```
1. skill letxinet-search-best-practices    <- PRERREQUISITO
2. letxinet-gateway_batch_search(
     queries=["bacterial cellulose Komagataeibacter mango","BC production mango peel","Komagataeibacter medellinensis"],
     maxResults=80,
     sources=["pubmed","openalex","scielo","renati","serpapi"]
   )
3. Para cada paper relevante:
   letxinet-gateway_resolve_pdf(doi=...)
   letxinet-gateway_pdf_smart_summary(source=..., maxTotalChars=6000)
   letxinet-gateway_extract_section(source=..., section="results")
4. Recoger claims numericos en un texto a verificar:
   text_to_verify = "La produccion de BC alcanzó 12.4 g/L usando Komagataeibacter medellinensis (Garcia-Sanchez, 2019). El sustrato mango mostro eficiencia del 87% en comparacion con glucosa."
5. letxinet-gateway_verify_antihallucination_data(
     text_to_verify=text_to_verify,
     extracted_source_texts=[seccion_results_paper_1, seccion_results_paper_2, ...]
   )
   -> Devuelve {matches: [...], mismatches: [...], corrections: [...]}
6. omni-word-mcp_create_document("Revision-Sistematica-BC-Mango.docx")
7. omni-word-mcp_add_heading("Resumen", 1)
   omni-word-mcp_add_paragraph("Revision sistematica con verificacion anti-alucinacion automatizada")
8. omni-word-mcp_add_heading("Metodologia", 1)
   omni-word-mcp_add_paragraph("Busqueda en 5 fuentes: PubMed, OpenAlex, SciELO, RENATI, SerpAPI. 80 papers recuperados, 12 analizados a profundidad, 4 verificicados anti-alucinacion")
9. omni-word-mcp_add_heading("Resultados Verificados", 1)
   Para cada claim:
     omni-word-mcp_add_paragraph(claim_verificado_o_corregido)
10. omni-word-mcp_add_heading("Discrepancias Detectadas por Anti-Alucinacion", 1)
    omni-word-mcp_add_table(rows=mismatches+1, cols=4, data=[["Claim","Source","Discrepancia","Correccion"],...])
11. omni-word-mcp_add_heading("Referencias", 1)
12. add_heading("Anexo: Logs Anti-Alucinacion", 1)
    omni-word-mcp_add_paragraph(JSON.stringify(verifier_response, null, 2))
```

**Tiempo estimado:** 30-45 minutos por revision completa
**Herramientas combinadas:** 5 Gateway + 4 Word = 9 tools
**KEY:** `verify_antihallucination_data` compara tus claims vs textos extraidos previamente

---

## 6. Caso 6: Predictive Emissions Study para Logistica (MCP-OSM + MCP-Gateway + MCP-Word)

**Contexto:** Empresa de transporte quiere estimar emisiones CO2 de 5 rutas candidatas y citar literatura

### Flujo (8 pasos)

```
1. Para cada par (origen, destino) de 5 routes:
   letxinet-osm_route_fetch(start={lat,lon}, end={lat,lon}, mode="car")
2. letxinet-osm_enrich_emissions(options=[
     {mode:"car", distance: distance_route_1, duration: duration_route_1},
     {mode:"car", distance: distance_route_2, duration: duration_route_2},
     ...
   ])
   -> retorna CO2, calorias, costo por ruta
3. letxinet-gateway_search(
     query="CO2 emissions road transport 2024",
     sources=["scielo","openalex","pubmed","crossref"],
     fastMode=true
   )
4. letxinet-gateway_extract_section(pdf_url, "results")  -> sacar dato CO2 del paper mas relevante
5. omni-word-mcp_create_document("Analisis-Emisiones-Rutas.docx")
6. omni-word-mcp_add_heading("Introduccion", 1)
   omni-word-mcp_add_paragraph(...)
7. omni-word-mcp_add_heading("Rutas Analizadas", 1)
   omni-word-mcp_add_table(rows=6, cols=5, data=[["Ruta","Distancia km","Duracion min","CO2 estimado kg","Costo $"],...])
8. omni-word-mcp_add_heading("Comparativa con Literatura", 1)
   omni-word-mcp_add_paragraph("Segun <autor> (year), las emisiones para vehiculos similares...")
```

**Tiempo estimado:** 10-15 minutos
**Herramientas combinadas:** 3 OSM + 2 Gateway + 3 Word = 8 tools

---

## 7. Caso 7: Extraccion de Datos Estadisticos y Verificacion (MCP-Gateway + MCP-Word)

**Contexto:** Estudiante necesita extraction programmatica de p-values, ANOVAs, sample sizes de 30 PDF)

### Flujo (5 pasos)

```
1. skill letxinet-search-best-practices
2. letxinet-gateway_batch_search(queries=[...30 keywords...], maxResults=200, sources=...)
3. Para cada paper de 30 (batch inverso):
   letxinet-gateway_analyze_academic(source=pdf_url)
   -> retorna {documentType, language, sections, statistics:{p_values:[], correlations:[], anova:[], chi2:[], regressions:[], sample_sizes:[]}}
4. omni-word-mcp_create_document("Stats-Extraction-30-papers.docx")
5. omni-word-mcp_add_table(rows=31, cols=8, data=[["Paper","p-values","correlations","ANOVA","chi2","regressions","sample_sizes","language"],...])
```

**Tiempo estimado:** 30-60 minutos para 30 papers
**Herramientas combinadas:** 2 Gateway + 2 Word = 4 tools
**Beneficio:** El estudiante tiene todos los stats en una tablita Excel-ready

---

## 8. Caso 8: Documento Tripadvisor Tesis Biologia (MCP-Gateway + MCP-OSM + MCP-Word)

**Contexto:** Tesis sobre biodiversidad en un parque nacional — paper academico + ubicaciones + reporte Word

### Flujo (8 pasos)

```
1. letxinet-gateway_search(query="biodiversidad Parque Nacional Manu", sources=["scielo","renati","laref_peru","serpapi"], fastMode=true)
2. letxinet-gateway_search(query="Manu National Park species diversity", sources=["pubmed","openalex","crossref"], fastMode=true)
3. letxinet-osm_polygon_from_admin(name="Manu", admin_level=4)  -> parque boundary
4. letxinet-osm_find_nearby_places(lat=centro.parque, lon=..., category="research_station", radius=50000, limit=10)
5. Para cada paper clave:
   letxinet-gateway_pdf_smart_summary(source=pdf_url, maxTotalChars=5000)
6. omni-word-mcp_create_document("Informe-Manu-Biodiversidad.docx")
7. omni-word-mcp_add_heading("1. Introduccion", 1)
   omni-word-mcp_add_paragraph("El Parque Nacional Manu...")
   omni-word-mcp_add_heading("2. Ubicacion Geografica", 1)
   omni-word-mcp_add_paragraph("Lat: -11.8, Lon: -71.4, Area: 1.9M ha")
   omni-word-mcp_add_picture("poligono_manu.png")
   omni-word-mcp_add_heading("3. Estaciones de Investigacion", 1)
   omni-word-mcp_add_table(rows=estaciones+1, cols=4, data=[["Nombre","Distancias","Tipo","Actividad"],...])
8. omni-word-mcp_add_heading("4. Revision de Literatura", 1)
   Para cada paper:
     omni-word-mcp_add_paragraph("- <autor> (<ano>). <title>. Encontraron: <resumen>")
```

**Tiempo estimado:** 25-40 minutos
**Herramientas combinadas:** 2 Gateway + 2 OSM + 4 Word = 8 tools

---

## 9. Caso 9: Bilingual Academic Summary (Multilingual TS Translation)

**Contexto:** Sponsor quiere version ES + EN de un paper abstract para concurso

### Flujo (5 pasos)

```
1. skill letxinet-search-best-practices
2. letxinet-gateway_search(query="organic fertilizer effects tomatoes yield", sources=["pubmed","openalex","crossref"], fastMode=true)
3. letxinet-gateway_extract_section(source=pdf_url, section="abstract")
4. omni-word-mcp_create_document("Resumen-Bilingue-2026.docx")
5. omni-word-mcp_add_heading("Abstract (English)", 1)
   omni-word-mcp_add_paragraph(abstract_extraido)
   omni-word-mcp_add_heading("Resumen (Spanish)", 1)
   omni-word-mcp_add_paragraph(traduccion_es Abstract)
```

**Tiempo estimado:** 5 minutos

---

## 10. Caso 10: Full Research Pipeline — LetXinet Suite Case

**Contexto:** Promotor/promotora de investigacion hace todo el pipeline en una tarde

### Flujo Mastodonte (20+ pasos)

```
[FASE A — DESCUBRIMIENTO]
1. skill letxinet-search-best-practices
2. letxinet-gateway_batch_search(queries=[
     "bacterial cellulose mango",
     "Komagataeibacter medellinensis production",
     "mango peel substrate biotechnology"
   ], maxResults=80, sources=["pubmed","openalex","scielo","renati","serpapi"])
3. Filtrar 3 mejores papers por QualityScore
4. letxinet-gateway_enrich_metadata(papers=[best_3_papers])

[FASE B — ANALISIS PROFUNDO]
5. Para cada paper:
   letxinet-gateway_resolve_pdf(doi=...)
   letxinet-gateway_pdf_smart_summary(source=resolved_url, maxTotalChars=6000)
   letxinet-gateway_extract_section(source=resolved_url, section="metodologia")
   letxinet-gateway_extract_section(source=resolved_url, section="results")
   letxinet-gateway_analyze_academic(source=resolved_url)
   -> extraer {statistics, sections}

[FASE C — VERIFICACION ANTI-ALUCINACION]
6. letxinet-gateway_verify_antihallucination_data(
     text_to_verify="LA BC alcanzó 14.2 g/L usando K. medellinensis y mango como sustrato (p<0.01)",
     extracted_source_texts=[seccion_results_dos_papers]
   )

[FASE D — COMPLEMENTO GEOGRAFICO]
7. letxinet-osm_geocode_address("Medellin, Colombia")
   letxinet-osm_analyze_neighborhood(lat=medellin.lat, lon=medellin.lon, radius=5000)
   letxinet-osm_find_nearby_places(lat, lon, category="university", limit=5)

[FASE E — INFORME WORD]
8. omni-word-mcp_create_document("Informe-Final-Set-K-BC-Mango.docx", title="Informe Final", author="LetXinet Gateway")
9. omni-word-mcp_add_heading("1. Resumen", 1)
   omni-word-mcp_add_paragraph(" estudio analizó 80 papers... 3 papers elegidos para profundidad...")
10. omni-word-mcp_add_heading("2. Hallazgos Clave", 1)
    omni-word-mcp_add_paragraph("- Hallazgo 1...")
    omni-word-mcp_add_paragraph("- Hallazgo 2...")
    omni-word-mcp_add_paragraph("- Hallazgo 3...")
11. omni-word-mcp_add_heading("3. Metodologia", 1)
    omni-word-mcp_add_paragraph("Busqueda en 5 fuentes (latam + global) via LetXinet Gateway V11...")
12. omni-word-mcp_add_heading("4. Verificacion Anti-Alucinacion", 1)
    omni-word-mcp_add_table(rows=verifications+1, cols=4, data=[...])
13. omni-word-mcp_add_heading("5. Contexto Geografico", 1)
    omni-word-mcp_add_paragraph("Medellin, Colombia - ubicacion central de la actividad investigativa")
14. omni-word-mcp_add_heading("6. Referencias", 1)
    Para cada paper:
      omni-word-mcp_add_paragraph("1. <autor> (<ano>). <title>. <journal>. DOI: <doi>")
15. save + format_text con negritas a hallazgos clave

[FASE F — COMPLEMENTO ESTATICO PDF]
16. markitdown-api_markitdown_convert(
      path="D:\\OtroPaperReferencia.pdf",
      pages="1-3",
      maxChars=10000
    )  -> backup local paper
17. omni-word-mcp_add_heading("7. Anexo: Paper de referencia extraido via MarkItDown", 1)
    omni-word-mcp_add_paragraph(markdown_extraido)
```

**Tiempo estimado:** 1-2 horas (mayormente latencia PDF extractions)
**Herramientas combinadas:** 8 Gateway + 3 OSM + 1 MarkItDown + 6 Word = 18 tools diferentes

---

## 11. Patrones Recurrentes a Recordar

### 11.1 Siempre cargar el skill primero!

```
skill letxinet-search-best-practices  
```

Sin esta skill, el modelo puede invocar group sources (`latam`, `all`) que colapsan el bridge o perder 90s en DEAD sources (`alicia`).

### 11.2 Chain basico: Buscar -> Resolver -> Leer -> Word

```
search -> resolve_pdf -> pdf_smart_summary ->  extract_section -> verify_antihallucination_data -> omni-word-mcp create_document -> add_pdf_paragraph
```

6 tools encadenadas = investigacion bibliografica completa en una tarde.

### 11.3 Chain geoespacial: Geocode -> Analyze -> Find -> Route -> Word

```
geocode_address ->  analyze_neighborhood -> find_nearby_places -> get_route_directions -> omni-word-mcp_create_document + add_table
```

5 tools = site selection report en 5 minutos.

### 11.4 Chain conversion: MarkItDown -> Parse -> Word

```
markitdown-api_markitdown_convert -> (parse markdown) -> omni-word-mcp_create_document -> add_heading + add_paragraph + add_table
```

3 tools = PDF scaneado a Word editable en 10 minutos.

### 11.5 Chain revision sistematica: Batch search + Anti-alucinacion

```
batch_search -> enrich_metadata -> [loop papers] resolve_pdf + extract_section + analyze_academic -> verify_antihallucination_data -> omni-word-mcp_create_document + add_table
```

10+ tools = revision sistematica con datos verificar en 30-45 minutos.

---

## 12. Parametros Criticos de Configuracion

### 12.1 Timeouts en opencode.json

```json
"mcp": {
  "letxinet-gateway":  { "timeout": 3600000 },  // 60 min — academic search y  PDF analysis son lentos
  "letxinet-osm":     { "timeout": 60000 },     // 1 min — OSM es rapido
  "letxinet-markitdown": { "timeout": 1800000 }, // 30 min — OCR de PDFs grandes
  "omni-word-mcp":    { "timeout": 60000 }       // 1 min — docx creation es rapido
}
```

### 12.2 API Keys necesarias (en shell env o secrets.json)

```
SERPAPI_API_KEY    - para `serpapi` source (HIDDEN TREASURE Google Scholar wrapper)
SCOPUS_API_KEY     - para `scopus` source (Elsevier)
OPENALEX_EMAIL     - para `openalex` (polite pool)
CORE_API_KEY       - para `core` source (opcional)
```

Las demas fuentes (renati, scielo, laref_*, pubmed, crossref, etc.) NO requieren API key.

### 12.3 Servicios backend necesarios

Antes de invocar MCP tools:

1. Suite backend debe estar corriendo (NSSM services up)
2. Para MarkItDown MCP sin Suite: standalone Python service
   ```
   cd D:\OTROS\LETXINET-SUITE\src-suite\componentes-parches\markitdown-api\markitdown-payload
   python app.py  # arranca puerto 7860
   ```
3. Para OSM MCP:
   ```
   D:\OTROS\letxipu-osm-mcp\osmmcp-patched.exe  # arranca puerto 7082
   ```

---

## 13. Anti-Patrones (EVITAR)

### NO hacer esto:

- `sources=["latam"]` o `["all"]` o `["tesis"]` o `["iberoamerica"]` (groups colapsan bridge)
- `sources=["alicia"]` (90s timeout)
- Llamar `recover_metadata` (timeout 240s)
- Llamar `pdf_sections` en PDFs >30 pags (timeout >4min)
- Hacer loops con `search` sin `fastMode:true` (3x mas lento)
- Cargar MarkItDown MCP sin haber arrancado `python app.py` primero
- Crear documento Word grande entero en un solo `add_paragraph` (romper flujo)

### SI hacer esto:

- `sources=["<individual_source>"]` con `fastMode:true` y `maxSources=5`
- Pasar LTE budgets tokens (`maxTotalChars=4000-8000`) a `pdf_smart_summary`
- Encadenar: search -> resolve_pdf -> pdf_smart_summary -> extract_section
- Cargar skill antes de cualquier busqueda academica
- Hacer add_heading por seccion en Word (no mega-paragraph)
- Verificar anti-alucinacion en claims numericos criticos
- Usar tablas en Word para comparativas (format_table para borders)

---

**Fin del Plan de Combinaciones.**

Practices concretas: copiar estos flujos a instrucciones del agente en opencode.json para automatizar comportamientos.
